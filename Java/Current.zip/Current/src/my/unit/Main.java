package my.unit;
import java.util.Date;

public class Main {

	public static void main(String[] args) {
		//Date b = null;
		Unit u1 = new Unit(5);
		Unit u2 = new Unit(5);
		System.out.println(u1.toString());
		System.out.println(u2.toString());
		
	}

}
