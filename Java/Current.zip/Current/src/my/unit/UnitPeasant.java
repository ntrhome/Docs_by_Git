package my.unit;

public class UnitPeasant extends Unit{
	public UnitPeasant(int owner) {
		//super()
	}
}
