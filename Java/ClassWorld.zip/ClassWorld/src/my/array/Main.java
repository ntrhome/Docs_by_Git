package my.array;

public class Main {

	public static void main(String[] args) {
		
		int[] array = new int[] {9,8,7,6,5,4,3,2,1,0};
		
		//System.out.println("> " + array.length);
		
		for(int i : array)
			System.out.println("> " + i);
		
		System.out.println("> " + array);
		
		

	}

}
