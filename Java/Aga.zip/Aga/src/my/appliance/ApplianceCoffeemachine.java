package my.appliance;

public class ApplianceCoffeemachine extends Appliance {
	private ApplianceCoffeemachineBox box;
	
	

}
