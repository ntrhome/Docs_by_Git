package my.appliance;

public class Appliance {
	private String name;
	private String brand;
	private String powerType;
	
	
	
	
	
}
